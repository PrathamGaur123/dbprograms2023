#Program to accept company like "samsung" and display list of mobiles of that category in the ascending order of price
import pymysql
from tabulate import tabulate

con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
print("Successfully Connected")
curs = con.cursor()

company = input("Enter Comapany Name: ")
curs.execute("select * from mobiles where company='%s' order by price asc" %company)
data = curs.fetchall()
fields = ['Product ID','Model Name', 'Company', 'Connectivity', 'RAM', 'ROM', 'Color', 'Screen', 'Battery', 'Processor', 'Price', 'Ratings', 'Purpose']
print(tabulate(data, headers=fields))

con.close()
