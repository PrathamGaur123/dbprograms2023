#Create a table "MOBILES" with prodid as primary key and other fields like modelname, company, connectivity(4G/5G), ram, rom, color, screen, battery, processor, price, rating (4.3 out of 5)
import pymysql

con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
print("Successfully Connected")
curs = con.cursor()

curs.execute("create table mobiles(prodid int primary key, modelname varchar(100), company varchar(100), connectivity varchar(5), ram int, rom int, color varchar(50), screen float, battery int, processor varchar(100), price int, ratings float)")

con.close()
