#program to display group by information - brand, total models under the company, average price and average rating.
import pymysql
from tabulate import tabulate

con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
print("Successfully Connected")
curs = con.cursor()

curs.execute("select company, count(modelname), avg(price), avg(ratings) from mobiles group by company")
data = curs.fetchall()
fields = ['Product ID','Model Name', 'Company', 'Connectivity', 'RAM', 'ROM', 'Color', 'Screen', 'Battery', 'Processor', 'Price', 'Ratings', 'Purpose']
print(tabulate(data, headers=fields))

con.close()
