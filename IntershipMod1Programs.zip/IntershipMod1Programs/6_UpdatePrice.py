#Write a program to accept prodid & new price and update price in the mobile data in the table if found else display "mobile does not exist"
import pymysql

con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
print("Successfully Connected")
curs = con.cursor()

pid = int(input("Enter Product ID: "))
curs.execute("select * from mobiles where prodid=%d" %pid)
data = curs.fetchone()
if data:
    print("Current Price: ",data[10])
    price = int(input("Enter New Price: "))
    curs.execute("update mobiles set price=%d where prodid=%d" %(price,pid))
    con.commit()
    print("Mobile Price Updated Successfully")
    curs.execute("select * from mobiles where prodid=%d" %pid)
    data = curs.fetchone()
    print("New Price: ",data[10])
else:
    print("Mobile does not exist")

con.close()
