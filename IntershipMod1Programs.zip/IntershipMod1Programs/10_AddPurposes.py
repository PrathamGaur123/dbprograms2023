#Program to accept modelname and purpose, update all mobiles of the model with the purpose ( gaming/office/social, etc.)
import pymysql

con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
print("Successfully Connected")
curs = con.cursor()

modnm = input("Enter Model Name: ")
curs.execute("select * from mobiles where modelname='%s'" %modnm)
data = curs.fetchone()
if data:
    print(data)
    purpose = input("Enter Purpose: ")
    curs.execute("update mobiles set purpose='%s' where modelname='%s'" %(purpose,modnm))
    con.commit()
    print("Purpose Added Successfully")
else:
    print("Mobile not found")

con.close()
