#Program to take new mobile data as input and add mobile to the DB table

import pymysql

con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
print("Successfully Connected")
curs = con.cursor()

pid = int(input("Enter Product ID: "))
mobname = input("Enter Mobile Name: ")
company = input("Enter Company: ")
connectivity = input("Enter Connectivity 4G///5G: ")
ram = int(input("Enter RAM Size: "))
rom = int(input("Enter ROM Size: "))
color = input("Enter Color: ")
screen = float(input("Enter Screen Size in inches: "))
battery = int(input("Enter Battery in mAh: "))
processor = input("Enter Processor: ")
price = int(input("Enter Price: "))
ratings = float(input("Enter Ratings out of 5: "))
try:
    curs.execute("insert into mobiles values(%d,'%s','%s','%s',%d,%d,'%s',%2.f,%d,'%s',%d,%2.f)" %(pid,mobname,company,connectivity,ram,rom,color,screen,battery,processor,price,ratings))
    con.commit()
    print("New Mobile Data Inserted Successfully")
except:
    print("Can't Insert Mobile Data")

con.close()
