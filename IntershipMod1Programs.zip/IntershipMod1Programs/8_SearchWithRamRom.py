# program to accept ram and rom, display list of mobiles of the ram-rom storage space combination
import pymysql

con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
print("Successfully Connected")
curs = con.cursor()

ram = int(input("Enter RAM Size: "))
rom = int(input("Enter ROM Size: "))
try:
    curs.execute("select * from mobiles where ram=%d and rom=%d" %(ram,rom))
    data = curs.fetchone()
    print(data)
except:
    print("No Mobiles with such specification")

con.close()
