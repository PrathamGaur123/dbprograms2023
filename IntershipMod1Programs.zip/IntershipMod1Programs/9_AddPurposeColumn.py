#Add new column "purpose varchar(50)" to the mobiles table using alter query
import pymysql

con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
print("Successfully Connected")
curs = con.cursor()

column = input("Enter name of new Column: ")
datatype = input("Enter data type: ")
try:
    curs.execute("alter table mobiles add "+column+" "+datatype)
    con.commit()
    print("Column Added")
except:
    print("Cannot insert Column")

con.close()
