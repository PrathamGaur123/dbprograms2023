#program to accept prodid, display the mobile data and ask "Do you want to delete?" if "yes" delete the mobile from the table
import pymysql

con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
print("Successfully Connected")
curs = con.cursor()

pid = int(input("Enter Product ID to Delete the Mobile Data: "))
curs.execute("select * from mobiles where prodid=%d" %pid)
data = curs.fetchone()
if data:
    print(data)
    choice = input("Are you sure want to delete this Mobile Record? (yes/no): ")
    if choice.lower() == 'yes':
        curs.execute("delete from mobiles where prodid=%d" %pid)
        con.commit()
        print("Mobile Record Deleted Successfully")
    else:
        print("Mobile Record Deletion Cancelled")
else:
    print("Mobile does not exist")

con.close()
