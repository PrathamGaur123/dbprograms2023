#Program to accept modelname, search mobile in the table, show the mobile details if found else display "not found" message
import pymysql
from tabulate import tabulate

con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
print("Successfully Connected")
curs = con.cursor()

modnm = input("Enter Model Name: ")
try:
    curs.execute("select * from mobiles where modelname=\'%s\'" %modnm)
    data = curs.fetchone()
    print(data)
except:
    print("Mobile Data Not Found.")

con.close()
