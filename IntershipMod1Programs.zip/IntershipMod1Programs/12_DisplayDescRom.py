#Take field as an input like rom and display all mobiles in the descending order of the that field.
import pymysql
from tabulate import tabulate

con = pymysql.connect(host='bjdnzwywx4yuwlv2yvqn-mysql.services.clever-cloud.com', user='uryhne0taq31lhab', password='9ktaVYjniKvGj207ouvQ', database='bjdnzwywx4yuwlv2yvqn')
print("Successfully Connected")
curs = con.cursor()

rom = int(input("Enter ROM Size: "))
curs.execute("select * from mobiles where rom<=%d order by rom desc" %rom)
data = curs.fetchall()
fields = ['Product ID','Model Name', 'Company', 'Connectivity', 'RAM', 'ROM', 'Color', 'Screen', 'Battery', 'Processor', 'Price', 'Ratings', 'Purpose']
print(tabulate(data, headers=fields))

con.close()
